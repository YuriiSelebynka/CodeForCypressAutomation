This is a compilation of code for educational purposes.
Source: Udemy Cypress Automation Testing.

In VS Code:
1. mkdir NAMEOFPROJECT
2. cd NAMEOFPROJECT
3. npm -i init AFTER - yes
4. npm install cypress --save-dev

node_modules\.bin\cypress open 
npm install -D cypress-iframe
node_modules\.bin\cypress run --spec cypress\integration\examples\Test9Framework.js --env url=http://google.com --headed 
npm install --save-dev mochawesome
npm install --save-dev mocha
cypress run --reporter mochawesome 
node_modules\.bin\cypress run --reporter mochawesome --spec cypress\integration\examples\Test9Framework.js  
npm install cypress --save-dev 
java -jar jenkins.war -httpPort=9090  
npm install --save-dev cypress-cucumber-preprocessor   
https://github.com/TheBrainFamily/cypress-cucumber-preprocessor   
cypress run --spec D:\AngularProjects\my-test-program\cypress\integration\examples\BDD\ecommerce.feature --headed --browser chrome  
node_modules\.bin\cypress run --spec D:\AngularProjects\my-test-program\cypress\integration\examples\BDD\ecommerce.feature --headed --browser firefox  
node_modules\.bin\cypress run --spec D:\AngularProjects\my-test-program\cypress\integration\examples\BDD\*.feature --headed --browser firefox    
npx cypress-tags run -e TAGS="@Regression" --headed --browser firefox    
npm install multiple-cucumber-html-reporter --save-dev    
node cucumber-html-report.js    
npx cypress open    
npm install —save-dev cypress-sql-server    
npm init -y CREATING PACKAGE.JSON         
https://www.npmjs.com/package/cypress-sql-server
